<?Php 
session_start();
//error_reporting(0);
include("h2.php");
include 'Admin/connect.php';

$message = $link = '';
if(isset($_POST['btnsubmit'])) {
	$email = $_POST['email'];
	$query = "SELECT * FROM db_users WHERE email like '".$email."'";
	$result = $cn->query($query);
if($result->num_rows > 0){
	while($row = $result->fetch_assoc()){
		// $id = $row['id'];
		// $id_encode = base64_encode($id);
		
    $pass=$row['password'];
    // $to_mail="kashishsb2000@gmail.com";
$sub="Mail from XAMPP";
$body="Your password is--->$pass";
$he="MAIL FROM XAMPP";
if(mail($email,$sub,$body,$he))
    echo "Sent";
else
    echo "Error";

    // $link = "<a href='resetPassword.php?MnoQtyPXZORTE=$id_encode' class='btn btn-info btn-sm'>Recieve Mail</a>";
	}
	}else{
		$message = "<div class='alert alert-danger'>Invalid Email..!!</div>";
	}
	}
?>
  




<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="CS/css/bootstrap.min.css"> 
  <link href="CS/css/font-awesome.min.css" rel="stylesheet"> 
   <link href="CS/css/main.css" rel="stylesheet" > 
   <link href="CS/css/custom.css" rel="stylesheet" > 
<link rel="shortcut icon" href="../IMG/MCA Logo1.png" />
    <title>VTCBCSR</title>
    <style type="text/css">
    
    
   form{
    text-align:left;
    margin-left:150px;
    margin-right:150px;
   }
   
   h1{
	   
    text-align:center;
    margin-top: 90px;
    font-size:40px;
    font-weight:bolder;
    color:gray;
  
   }
   h3{
	   
     text-align:center;
     font-size:30px;
     font-weight:bolder;
     color:blue;
   
    }
  
  
   
    </style>
  </head>
  <body>
   <!-- <section class="material-half-bg">
      <div class="cover"></div>
    </section> -->
   <!-- <section class="login-content"> -->
      <div class="logo">
        <h1>FORGOT PASSWORD</h1>
		 <h3 class="login-head"><i class="fa fa-lg fa-fw fa-user"></i>HOME / <span Style="color:black">FORGOT PASSWORD</span</h3>
      </div>
     
  
       

      <div class="login-box">
        <form class="login-form" method="post" >
        <?php echo $message; ?>
          <div class="form-group">
            <label class="control-label">Email</label>
            <input class="form-control" type="text"  required name="email" placeholder="Email" autofocus>
          </div>
          
		   <div class="form-group">
            <div class="utility">
              <div class="animated-checkbox">
                
              </div>
              </div>
          </div>
          <div class="form-group btn-container">
            <button class="btn btn-primary " name="btnsubmit" type="submit"><i class="fa fa-sign-in fa-lg fa-fw"></i>Reset</button>
            <?php echo $link; ?>
            <a href="signin.php" class="btn btn-info">Back</a>
           
           
          </div>
         
        </form>
      
        </div>
      </div>
    </section> 
	
    <!-- Essential javascripts for application to work-->
    <script src="CS/js/jquery-3.2.1.min.js"></script>
    <script src="CS/js/popper.min.js"></script>
    <script src="CS/js/bootstrap.min.js"></script>
    <script src="CS/js/main.js"></script>    
    <script type="text/javascript">
      // Login Page Flipbox control
      $('.login-content [data-toggle="flip"]').click(function() {
      	$('.login-box').toggleClass('flipped');
      	return false;
      });
    </script>
    
  </body>
</html>
<?php
include("footer.php");
?>