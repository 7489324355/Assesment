<?php 
session_start(); 
include("Admin/connect.php");
include("h1.php");

$q2="select * from db_users where email like'".$_SESSION['staff']."'"; 
$res2=mysqli_query($cn,$q2);
$row2=mysqli_fetch_object($res2);
$uid=$row2->id;

$q="select * from db_booking where seller_id='$uid'";
$res=mysqli_query($cn,$q);
$row=mysqli_fetch_object($res);

if(isset($_REQUEST['btnsubmit']))
{                  
    $q1="update db_booking set replay='".$_REQUEST['replay']."' where id=".$_GET['id'];
    mysqli_query($cn,$q1);

    echo "<Script Lang=javascript>"; 
    echo "window.location.href = 'enq_status.php' "; 
    echo "</script>";
}

// Check if there is a previous reply for this message
 $q2 = "SELECT replay FROM db_booking WHERE id=".$_GET['id'];
$res2 = mysqli_query($cn, $q2);
$row2 = mysqli_fetch_object($res2);
$previous_reply = $row2->replay ?? '';

$q3="select * from  db_properties_types";
$res3=mysqli_query($cn,$q3);
$row3=mysqli_fetch_object($res3);


?>

<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
</style>
</head>
<body>
<!-- <main class="app-content"> -->
<section class="intro-single">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-8">
            <div class="title-single-box">
              <h1 class="title-single">Recive Enquiry</h1>
              <!-- <span class="color-text-a">Grid Properties</span> -->
            </div>
          </div>
          <div class="col-md-12 col-lg-12" style="margin-right: 2000px;">
            <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="#">Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                  Properties Grid
                 
                </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </section><!-- End Intro Single-->
   <main class="app-content">
 
  <form method="post" enctype="multipart/form-data">
    <div style="display: flex; justify-content: center; align-items: center; height: 100vh;">
      <table style="width: 100%;" class="display table table-striped table-advance table-hover" id="documentstbl">
        <tr>
          <th style="width:20%">ID</th>
          <td><?php echo $row->id; ?></td>
        </tr>

        <tr>
          <th style="width:20%">Name</th>
          <td>
            <?php 
              $sid=$row->buyer_id;  
              $q1="select * from db_users  where id=".$sid;
              $res1=mysqli_query($cn,$q1);
              $row1=mysqli_fetch_object($res1);
              echo $row1->name;
            ?>
          </td>
        </tr>

        <tr>
          <th style="width:20%">Propety Title</th>
          <td><?php echo $row3->property_type;  ?></td>
        </tr>


        <tr>
          <th style="width:20%">Mobile Number</th>
          <td><?php echo $row->contactno;  ?></td>
        </tr>

        <tr>
          <th style="width:20%">Message</th>
          <td><?php echo $row->message;  ?></td>
        </tr>
         
        <tr>
          <th style="width:20%">Enquiry Date</th>
          <td><?php echo $row->enquiryd; ?></td>
        </tr>

        <tr>
          <th style="width:20%">Status</th>
          <td><?php echo $row2->replay; ?></td>
        </tr>

        <tr>
          <th style="width:20%">Remark</th>
          <td><textarea  name="replay" value=""></textarea></td>
        </tr>

        <tr>
          <td colspan="2" style="text-align: center;">
            <button class="btn btn-success"  type="submit" name="btnsubmit">Send</button>
          </td>
        </tr>
      </table>
    </div>
  </form>
</main>
</body>
</html>

