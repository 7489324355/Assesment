<?php 
include("Admin/connect.php");
include("h1.php");  
$q="select * from db_properties where id=".$_GET['id'];
$res=mysqli_query($cn,$q);
$row=mysqli_fetch_object($res);
// echo "<pre>";
// print_r($row);
//exit;

$u= $_SESSION['staff']; 
$q2="select * from db_users where email like '$u'";
$res2=mysqli_query($cn,$q2);
$row2=mysqli_fetch_object($res2);
$uid=$row->user_id;

if(isset($_REQUEST['btnsubmit'])) {    
    $brand = $_POST["brands"];
    $lang = implode(",", $brand);                 
    $q1 = "UPDATE db_properties SET ";
    $q2 = "";
    $q3 = " WHERE id=".$_GET['id'];
    if (!empty($_FILES['myfile']['name'])) {
        $q2 .= "propertyimage='".$_FILES['myfile']['name']."', ";
        move_uploaded_file($_FILES['myfile']['tmp_name'],"admin/img/".$_FILES['myfile']['name']);
    }
    if (!empty($_FILES['img1']['name'])) {
        $q2 .= "g1='".$_FILES['img1']['name']."', ";
        move_uploaded_file($_FILES['img1']['tmp_name'],"admin/img/".$_FILES['img1']['name']);
    }
    if (!empty($_FILES['img2']['name'])) {
        $q2 .= "g2='".$_FILES['img2']['name']."', ";
        move_uploaded_file($_FILES['img2']['tmp_name'],"admin/img/".$_FILES['img2']['name']);
    }
    if (!empty($_FILES['img3']['name'])) {
        $q2 .= "g3='".$_FILES['img3']['name']."', ";
        move_uploaded_file($_FILES['img3']['tmp_name'],"admin/img/".$_FILES['img3']['name']);
    }
    if (!empty($_FILES['img4']['name'])) {
        $q2 .= "g4='".$_FILES['img4']['name']."', ";
        move_uploaded_file($_FILES['img4']['tmp_name'],"admin/img/".$_FILES['img4']['name']);
    }
    if (!empty($_FILES['img5']['name'])) {
        $q2 .= "g5='".$_FILES['img5']['name']."', ";
        move_uploaded_file($_FILES['img5']['tmp_name'],"admin/img/".$_FILES['img5']['name']);
    }
    if (!empty($_FILES['img6']['name'])) {
        $q2 .= "video='".$_FILES['img6']['name']."', ";
        move_uploaded_file($_FILES['img6']['tmp_name'],"admin/img/".$_FILES['img6']['name']);
    }
    $q2 .= "city_id='".$_REQUEST['city']."', ".
           "user_id='$uid', ".
           "area_id='".$_REQUEST['area']."', ".
           "society_id='".$_REQUEST['society']."', ".
           "resident_id='".$_REQUEST['resident_type']."', ".
           "properties_type_id='".$_REQUEST['property_type']."', ".
           "status='".$_REQUEST['status']."', ".
           "price='".$_REQUEST['price']."', ".
           "size='".$_REQUEST['size']."', ".
           "Beds='".$_REQUEST['Beds']."', ".
           "Baths='".$_REQUEST['Baths']."', ".
           "Garages='".$_REQUEST['Garages']."', ".
           "property_des='".$_REQUEST['message']."', ".
           "feature='$lang'";
    $q1 .= $q2.$q3;
    $res1 = mysqli_query($cn, $q1);
    echo "<Script Lang=javascript>"; 
    echo "window.location.href = 'manage-pro.php' "; 
    echo "</script>";
}


?>


<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
.btn-warning{

position: relative;
padding: 3px 4px;
font-size: 15px;
line-height: 1;
border-radius: 3px;
color: white;
margin-left:50px;
background-color: cadetblue;
overflow: hidden;
}

.btn-warning input[type="file"]{
cursor: pointer;
position: absolute;
left: 0;
top: 0;
transform: scale(3);
opacity: 0;
}
</style>
</head>
<body>
<main class="app-content">
 
 <div class="row">
          <div class="col-lg-12">
		 
            <section class="panel">
              <header style=" font-weight:bolder; color:blue;  font-size:20px; margin-left:350px; margin-top:150px;" class="panel-heading">
                Property Details
              </header>
              <form role="form" method="post" enctype="multipart/form-data">



<table style="width:100%" class="display table table-striped table-advance table-hover" id="documentstbl">
  <tr>
  
    <th style="width:20%" >User name</th>
    <td><input  type="text"  class="form-control input-custom input-full" name="" placeholder="" value="<?php $cid=$row->user_id;  
		$q1="select * from db_users  where id=".$cid;
		$res1=mysqli_query($cn,$q1);
		$row1=mysqli_fetch_object($res1);
		echo $row1->name;
		 ?>">
     </td>
  </tr>
  <tr>
  <?php $cid=$row->city_id;  
		$q1="select * from db_city  where id=".$cid;
		$res1=mysqli_query($cn,$q1);
		$row1=mysqli_fetch_object($res1);
		// echo $row1->city_name;
		 ?>
    <th style="width:20%" >City</th>
    <td><select name="city" class="form-control"  >
                      
            <?php 
            echo "<option value=".$row1-> id.">".$row1->city_name."</option>";
            
            $q="select * from db_city where id !=".$cid;
                       $res=mysqli_query($cn,$q);
             
          while($rowcity=mysqli_fetch_object($res))
          {
              echo "<option value=".$rowcity-> id.">".$rowcity->city_name."</option>";
          }
          ?>
          
        </select>
       </td>
  </tr>
  <tr>
    <?php $sid=$row->society_id;  
		$q3="select * from db_society where id=".$sid;
		$res3=mysqli_query($cn,$q3);
		$row3=mysqli_fetch_object($res3);
		// echo $row3->society_name;
		 ?>
    <th style="width:20%">society</th>
    <td><select name="society" class="form-control" >
                      
             <?php 
            echo "<option value=".$row3-> id.">".$row3->society_name."</option>";
            
            $q="select * from db_society where id !=".$sid;
                       $res=mysqli_query($cn,$q);
             
          while($rowsociety=mysqli_fetch_object($res))
          {
              echo "<option value=".$rowsociety-> id.">".$rowsociety->society_name."</option>";
          }
          ?>
          
        </select></td>
  </tr>
  <tr>
    
    <?php $sid=$row->area_id;  
		$q4="select * from db_area where id=".$sid;
		$res4=mysqli_query($cn,$q4);
		$row4=mysqli_fetch_object($res4);
		// echo $row3->society_name;
		 ?>
    <th style="width:20%">Area</th>
    <td><select name="area" class="form-control" >
                      
             <?php 
            echo "<option value=".$row4-> id.">".$row4->areaname."</option>";
            
            $q="select * from db_area where id !=".$sid;
                       $res=mysqli_query($cn,$q);
             
          while($rowarea=mysqli_fetch_object($res))
          {
              echo "<option value=".$rowarea-> id.">".$rowarea->areaname."</option>";
          }
          ?>
          
        </select></td>
  </tr>
  <tr>
  <?php $cid=$row->resident_id;  
		$q5="select * from db_resident_types  where id=".$cid;
		$res5=mysqli_query($cn,$q5);
		$row5=mysqli_fetch_object($res5);
		// echo $row1->resident_type;
		 ?>
    <th style="width:20%" >Resident Type</th>
    <td><select name="resident_type" class="form-control" >
                      
                      <?php 
                     echo "<option value=".$row5-> id.">".$row5->resident_type."</option>";
                     
                     $q="select * from db_resident_types where id !=".$cid;
                                $res=mysqli_query($cn,$q);
                      
                   while($rowresident=mysqli_fetch_object($res))
                   {
                       echo "<option value=".$rowresident-> id.">".$rowresident->resident_type."</option>";
                   }
                   ?>
                   
                 </select></td>
  </tr>
  <tr>
  <?php $cid=$row->properties_type_id;  
		$q6="select * from db_properties_types  where id=".$cid;
		$res6=mysqli_query($cn,$q6);
		$row6=mysqli_fetch_object($res6);
		// echo $row1->property_type;
		 ?>
    <th style="width:20%">Property Type</th>
    <td><select name="property_type" class="form-control" >
                      
                      <?php 
                     echo "<option value=".$row6-> id.">".$row6->property_type."</option>";
                     
                     $q="select * from db_properties_types where id !=".$cid;
                                $res=mysqli_query($cn,$q);
                      
                   while($rowpropety=mysqli_fetch_object($res))
                   {
                       echo "<option value=".$rowpropety-> id.">".$rowpropety->property_type."</option>";
                   }
                   ?>
                   
                 </select></td>
  </tr>
  <tr>
    <th style="width:20%" >Property Description</th>
    <td><input  type="text"  class="form-control input-custom input-full" name="message" placeholder="" value="<?php echo $row-> property_des ?>"></td>
  </tr>
  <tr>
  
    <th style="width:20%" >Status</th>
    <td>
      
    <select name="status" class="form-control" >
                      
    
    
                    <option><?php echo $row-> status ?></option>
                    <option value="SELL">SELL</option>
                    <option value="RENT">RENT</option>
                  

                 </select>
                 </td>
  </tr>
  <tr>
    <th style="width:20%" >Price</th>
    <td><input  type="text"  class="form-control input-custom input-full" name="price" placeholder="" value="<?php echo $row-> price ?>"></td>
  </tr>
  <tr>
    <th style="width:20%" >Size</th>
    <td name="size"><input  type="text"  class="form-control input-custom input-full" name="size" placeholder="" value="<?php echo $row-> size ?>"></td>
  </tr>
  <tr>
 

    <th style="width:20%" >Baths</th>
    <td name="Baths"><select name="Baths"class="form-control form-select form-control-a">
                <option><?php echo $row-> Baths ?></option>
                <option value="Baths">1</option>
                <option value="Baths">2</option>
                <option value="Baths">3</option>
              </select>
  </td>
  </tr>
  <tr>
    <th style="width:20%" >Beds</th>
    <td name="Beds"><select name="Beds"class="form-control form-select form-control-a">
                <option><?php echo $row-> Beds ?></option>
                <option value=1>1</option>
                <option value=2>2</option>
                <option value=3>3</option>
              </select></td>
  </tr>
  <tr>
    <th style="width:20%" >Garages</th>
    <td name="Garages">
    <select name="Garages"class="form-control form-select form-control-a">
                <option><?php echo $row-> Garages ?></option>
                <option value=1>1</option>
                <option value=2>2</option>
                <option value=3>3</option>
              </select></td>
  </tr>
 

  
</table>
<header style=" font-weight:bolder; color:blue;  font-size:20px; margin-left:350px;" class="panel-heading">
                GALLARY
              </header>
<table  style="width:100%" >
<tr>
    <th style="width:20% ;height:100px;" >Featured Image</th>
   
    <td><img style="margin-left:50px;" src="Admin/img/<?php echo $row->propertyimage; ?>" width="90" height="90">
    <div class="photoUpload">
    <button type="button" class="btn-warning">
              <i class="bi bi-upload"></i>
              <input type="file" name="myfile" class="form-control input-custom input-full">
  </div></td>
  </tr>
  <tr>
    <th style="width:20% ;height:100px;" >Gallary Image1</th>
    <td><img style="margin-left:50px;" src="Admin/img/<?php echo $row->g1; ?>" width="90" height="90">
    <div class="photoUpload">
    <button type="button" class="btn-warning">
              <i class="bi bi-upload"></i>
              <input type="file" name="img1" class="form-control input-custom input-full">
  </div></td>
  </tr>
  <tr>
    <th style="width:20% ;height:100px;" >Gallary Image2</th>
    <td><img style="margin-left:50px;" src="Admin/img/<?php echo $row->g2; ?>" width="90" height="90">
    <div class="photoUpload">
    <button type="button" class="btn-warning">
              <i class="bi bi-upload"></i>
              <input type="file" name="img2" class="form-control input-custom input-full">
  </div></td>
  </tr>
 <tr>
    <th style="width:20% ;height:100px;" >Gallary Image3</th>
    <td><img style="margin-left:50px;" src="Admin/img/<?php echo $row->g3; ?>" width="90" height="90">
    <div class="photoUpload">
    <button type="button" class="btn-warning">
              <i class="bi bi-upload"></i>
              <input type="file" name="img3" class="form-control input-custom input-full">
  </div></td>
  </tr>
  <tr>
    <th style="width:20% ;height:100px;" >Gallary Image4</th>
    <td type="file" name="myfile"><img style="margin-left:50px;" src="Admin/img/<?php echo $row->g4; ?>" width="90" height="90">
    <div class="photoUpload">
    <button type="button" class="btn-warning">
              <i class="bi bi-upload"></i>
              <input type="file" name="img4" class="form-control input-custom input-full">
  </div></td>
  </tr>
  <tr>
    <th style="width:20% ;height:100px;" >Gallary Image5</th>
    <td><img style="margin-left:50px;" src="Admin/img/<?php echo $row->g5; ?>" width="90" height="90">
    <div class="photoUpload">
    <button type="button" class="btn-warning">
              <i class="bi bi-upload"></i>
              <input type="file" name="img5" class="form-control input-custom input-full">
  </div></td>
  </tr>

  <tr>
    <th style="width:20% ;height:100px;">Video</th>
    <td>
      <video controls autoplay>
      <source  name="myfile" type="video/mp4" style="margin-left:50px ; " src="Admin/img/<?php echo $row->video; ?>" width="10" height="10">
</video>
<div class="photoUpload">
    <button type="button" class="btn-warning">
              <i class="bi bi-upload"></i>
              <input type="file" name="img6" class="form-control input-custom input-full">
  </div></td>
  </tr>
</table>

<header style=" font-weight:bolder; color:blue;  font-size:20px; margin-left:350px;" class="panel-heading">
                Property Features
              </header>


              <?php 
              $features= explode(",",$row-> feature);
              ?>



<table  style="width:100%" >
<tr>
    <th style="width:80% ;" >center cooling</th>
    <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" value="center cooling"   
    <?php 
    if(in_array("center cooling",$features)){
      echo "checked";}
      ?>></td>
    
     
  </tr>
  <tr>
    <th style="width:20% ;" >Balcony</th>
    <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" value="Balcony"   
    <?php 
    if(in_array("Balcony",$features)){
      echo "checked";}
      ?>></td>
    
  </tr>
  <tr>
    <th style="width:20% ;" >Pet Friendly</th>
    <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" value="Pet Friendly"   
    <?php 
    if(in_array("Pet Friendly",$features)){
      echo "checked";}
      ?>></td>
    
  </tr>
 <tr>
    <th style="width:20% ;" >Barbeque</th>
    <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" value="Barbeque"   
    <?php 
    if(in_array("Barbeque",$features)){
      echo "checked";}
      ?>></td>
   
    
  </tr>
  <tr>
    <th style="width:20% ;" >Fire Alarm</th>
    <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" value="Fire Alarm"   
    <?php 
    if(in_array("Fire Alarm",$features)){
      echo "checked";}
      ?>></td>
   
   
  </tr>
  <tr>
    <th style="width:20% ;">Modern Kitchen</th>
    <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" value="Modern Kitchen"   
    <?php 
    if(in_array("Modern Kitchen",$features)){
      echo "checked";}
      ?>></td>
    
   
  </tr>

  <tr>
    <th style="width:20% ;">Storage</th>
    <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" value="Storage"   
    <?php 
    if(in_array("Storage",$features)){
      echo "checked";}
      ?>></td>
   
   
  </tr>

  <tr>
    <th style="width:20% ;">Dryer</th>
    <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" value="Dryer"   
    <?php 
    if(in_array("Dryer",$features)){
      echo "checked";}
      ?>></td>
    
  </tr>
  <tr>
    <th style="width:20% ;">Heating</th>
    <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" value="Heating"   
    <?php 
    if(in_array("Heating",$features)){
      echo "checked";}
      ?>></td>
   
  </tr>
  <tr>
    <th style="width:20% ;">Pool</th>
    <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" value="Pool"   
    <?php 
    if(in_array("Pool",$features)){
      echo "checked";}
      ?>></td>
    
  </tr>
  <tr>
    <th style="width:20% ;">Laundry</th>
    <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" value="Laundry"   
    <?php 
    if(in_array("Laundry",$features)){
      echo "checked";}
      ?>></td>
   
  </tr>
  <tr>
    <th style="width:20% ;">Sauna</th>
    <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" value="Sauna"   
    <?php 
    if(in_array("Sauna",$features)){
      echo "checked";}
      ?>></td>
   
  </tr>
  <tr>
    <th style="width:20% ;">Gym</th>
    <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" value="Gym"   
    <?php 
    if(in_array("Gym",$features)){
      echo "checked";}
      ?>></td>
    
  </tr>
  <tr>
    <th style="width:20% ;">Elevator</th>
    <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" value="Elevator"   
    <?php 
    if(in_array("Elevator",$features)){
      echo "checked";}
      ?>></td>
   
  </tr>
  <tr>
    <th style="width:20% ;" >Dish Washe</th>
    <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" value="Dish Washe"   
    <?php 
    if(in_array("Dish Washe",$features)){
      echo "checked";}
      ?>></td>
    
  </tr>
  <tr>
    <th style="width:20% ;" >Emergency Exit</th>
    <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" value="Emergency Exit"   
    <?php 
    if(in_array("Emergency Exit",$features)){
      echo "checked";}
      ?>></td>
    
  </tr>
  
</table>
<table>
<th class="text-center">
                      <button type="submit" name="btnsubmit" class="btn btn-primary">Save Changes</button>
                    </div>
</th>

</form>
</body>
</html>
