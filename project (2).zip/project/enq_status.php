<?php 
session_start(); 

include("Admin/connect.php");
include("h1.php");
$q2="select * from db_users where email like'".$_SESSION['staff']."'"; 
$res2=mysqli_query($cn,$q2);
$row2=mysqli_fetch_object($res2);
$uid=$row->id;

$q="select * from db_booking where seller_id='$uid'";
$res=mysqli_query($cn,$q);
?>
<html lang="en">
<head>
<script>
$(document).ready(function() {
    $('#documentstbl').DataTable();
} );
</script>
</head>
<body>
<?php 
 if($role==2){
  ?>

<div class="form">
			<form action="">

            <section class="intro-single">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-8">
            <div class="title-single-box">
              <h1 class="title-single">Recive Enquiry</h1>
              <!-- <span class="color-text-a">Grid Properties</span> -->
            </div>
          </div>
          <div class="col-md-12 col-lg-12" style="margin-right: 2000px;">
            <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="#">Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                  Properties Grid
                 
                </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </section><!-- End Intro Single-->
   <main class="app-content">
 
 <div class="row">
          <div class="col-lg-12">
		  <!-- <h3 class="page-header"><i class="fa fa-table"></i>Recive enquiry</h3> -->
          <h5> Total Recive Enquiry <h5>
            <section class="panel">
              <header class="panel-heading">
              </header>
              <table   class="display table table-striped table-advance table-hover" id="documentstbl">
                   <thead>
			               <tr>
                      <th>s.no</th>
                      <!-- <th>Email</th> -->
					            <th>Name</th>
					           <th>Mobile Number</th>
                      <th>Message</th>
                      <th>Action</th>
                    
                    
                    </thead></tr>
                    <tr>
                    <?php 
    while($row=mysqli_fetch_object($res))
    {
    ?>
	    <td><?php echo $row->id;?></td>
        <!-- <td></td>  -->
        <td><?php $sid=$row->buyer_id;  
		$q1="select * from db_users  where id=".$sid;
		$res1=mysqli_query($cn,$q1);
		$row1=mysqli_fetch_object($res1);
		echo $row1->name;
		 ?></td>
        <td><?php echo $row->contactno;  ?></td> 
        <td><?php echo $row->message;  ?></td> 


        <td>
		<a href="bdetail.php?id=<?php echo $row->id ?>" class="btn btn-text">View Details</a>
        </td>
        
    </tr>
        
        </div>
        
		</main>
    </section>
     <?php 
    }
    ?>
    
 <?php
 
 }   

 