<?php 
session_start(); 

include("Admin/connect.php");
include("h1.php");
$q="select distinct user_id from db_properties ";
$res=mysqli_query($cn,$q);
?>


<main id="main">

    <!-- =======Intro Single ======= -->
    <section class="intro-single">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-8">
            <div class="title-single-box">
              <h1 class="title-single">Our Amazing Agents</h1>
              <span class="color-text-a">Grid Properties</span>
            </div>
          </div>
          <div class="col-md-12 col-lg-4">
            <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="#">Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                  Agents Grid
                </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </section><!-- End Intro Single-->
   
    <!-- ======= Agents Grid ======= -->
    



    <section class="agents-grid grid">
      <div class="container">


        <div class="row">
        <?php
while($row=mysqli_fetch_object($res)){
  ?>
       

<?php
$uid=$row->user_id;

 $q1="select * from db_users where id=$uid";
$res1=mysqli_query($cn,$q1);
$row1=mysqli_fetch_object($res1);
//print_r($row1);
//echo 

?>
          <div class="col-md-4">
            <div class="card-box-d">
              <div class="card-img-d">
              <img src="Admin/img/<?php echo $row1->profile; 
  
                 $q1="select distinct * from db_users where id=$uid";
                 $res1=mysqli_query($cn,$q1);
                  $row1=mysqli_fetch_object($res1);
                ?>" alt="" class="img-a img-fluid">
              </div>
              <div class="card-overlay card-overlay-hover">
                <div class="card-header-d">
                  <div class="card-title-d align-self-center">
                    <h3 class="title-d">
                      <a href="#" class="link-two"><?php echo $row1->name; 
  
             $q1="select * from db_users where id=$uid";
               $res1=mysqli_query($cn,$q1);
           $row1=mysqli_fetch_object($res1);
?>
                        <br></a>
                    </h3>
                  </div>
                </div>
                <div class="card-body-d">
                  <p class="content-d color-text-a">
                    Sed porttitor lectus nibh, Cras ultricies ligula sed magna dictum porta two.
                  </p>
                  <div class="info-agents color-a">
                    <p>
                      <strong>Phone: </strong> +<?php echo $row1->conatct_no; 
  
  $q1="select * from db_users where id=$uid";
    $res1=mysqli_query($cn,$q1);
 $row1=mysqli_fetch_object($res1);
?>
                    </p>
                    <p>
                      <strong>Email: </strong> <?php echo $row1->email; 
  
  $q1="select * from db_users where id=$uid";
    $res1=mysqli_query($cn,$q1);
 $row1=mysqli_fetch_object($res1);
?>
                    </p>
                  </div>
                </div>
                <div class="card-footer-d">
                  <div class="socials-footer d-flex justify-content-center">
                    <ul class="list-inline">
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-facebook" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-twitter" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-instagram" aria-hidden="true"></i>
                        </a>
                      </li>
                      <li class="list-inline-item">
                        <a href="#" class="link-one">
                          <i class="bi bi-linkedin" aria-hidden="true"></i>
                        </a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php
          }
        ?>  
     
    </section><!-- End Agents Grid-->

  </main><!-- End #main -->
