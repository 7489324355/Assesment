<?php 

session_start(); 
//error_reporting(0);
include("h2.php");
include("Admin/connect.php");

if(isset($_POST['btnsubmit']))
    {                  
   	echo 	$q="insert into db_users set
         name='".$_REQUEST['txtusername']."' ,
		 email='".$_REQUEST['txtuseremail']."' ,
		 password='".$_REQUEST['txtpassword']."' ,
		 conatct_no='".$_REQUEST['txtmobile']."' ,
		 pincode='".$_REQUEST['txtpincode']."' ,
		  role_id='".$_REQUEST['role']."',
      profile='".$_FILES['myfile']['name']."'
      
 		  ";
       move_uploaded_file($_FILES['myfile']['tmp_name'],"admin/img/".$_FILES['myfile']['name']);
       $rs1 = mysqli_query($cn,$q);
        
         
            $_SESSION['staff'] = strtolower($_POST['txtuseremail']);  
            
            
     echo "<Script Lang=javascript>"; 
     echo "window.location.href = 'index2.php' "; 
     echo "</script>";
         
           
               
              //echo "<Script Lang=javascript>"; 
             // echo "window.location.href = 'index2.php' "; 
             // echo "</script>";
              
        
              

  
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
  <meta charset="utf-8">
   
<style type="text/css">

  
    
    
   
   
   h1{
	   
     text-align:center;
     margin-top: 110px;
     font-size:50px;
     font-weight:bolder;
     color:gray;
   
    }
    h3{
      
      text-align:center;
      font-size:50px;
      font-weight:bolder;
      color:blue;

    
     }
   
     body{
			background-repeat:no-repeat;
			background-size: cover;
			background-position: center center;
		}
   
    </style>
  
  </head>
  <body  background="a5.jpeg">
    
      <div class="logo">
        <h1>REGISTER</h1>
		 <h3 class="login-head">HOME / <span class="color-a">REGISTER</span></h3>
      </div>
		 
      <div class="container">
                <div class="row">
                    <div class="col-md-5 mx-auto">
                        <div class="card card-body">
                          
      
                                                    
                            <form  enctype="multipart/form-data"  method="post" data-parsley-validate="" data-parsley-errors-messages-disabled="true" novalidate="" _lpchecked="1"><input type="hidden" name="_csrf" value="7635eb83-1f95-4b32-8788-abec2724a9a4">
                            
     
      <!-- <div class="form"> -->
        <!-- <form class="login-form" method="post" enctype="multipart/form-data" > -->
		
		  <div class="form-group">
            <label class="control-label">Name</label>
            <input  class="form-control" type="text"  required name="txtusername" placeholder="Enter name" autofocus>
          </div>
         
          <div class="form-group">
            <label class="control-label">Email</label>
            <input   class="form-control" type="email"  required name="txtuseremail" placeholder="Email" autofocus>
          </div>

          <div class="form-group ">
            <label class="control-label">Password</label>
            <input  class="form-control" type="password" required  name="txtpassword" placeholder="Password">
          </div>
		  <div class="form-group">
            <label class="control-label">Mobile No.</label>
            <input  class="form-control"  type="number"  required name="txtmobile" placeholder="conactc_no" autofocus>
          </div>
		  <div class="form-group">
            <label class="control-label">Pincode</label>
            <input  class="form-control"  type="number"  required name="txtpincode" placeholder="enter pincode" autofocus>
          </div>
		    <div class="form-group">
						 <label for="exampleInputcity">Role ID</label>
                    <select name="role" class="form-control">
                      <option value="">Select role</option>
                    <?php 
					$q="select * from db_role";
                     $res=mysqli_query($cn,$q);
					 
        while($row=mysqli_fetch_object($res))
        {
            echo "<option value=".$row-> id.">".$row->name."</option>";
        }
        ?>
                    </select> 
                  </div>
				  <div class="form-group">
           Upload profile : <input type="file" accept="image/*" name="myfile">
      
		   </div>

		  
      
          <div class="form-group btn-container">
            <button class="btn btn-primary btn-block" name="btnsubmit" type="submit" ><i class="fa fa-sign-in fa-lg fa-fw"></i>Signup</button>
          </div>
          <div class="text-center add_top_10" class="btn btn-dark">Already have an acccount? <strong><a href="signin.php"><span style="color:blue">Sign In</span></a></strong></div>
   
        </form>
      
        </div>
      </div>
      </div>
                </div>
            
    </section> 
    
    
  </body>
</html>
<?php
include("footer.php");
?>