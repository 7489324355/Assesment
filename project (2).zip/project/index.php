<?php
include("h2.php");
include("into.php"); 
include("service.php"); 
include("latest_property.php"); 
include("agents.php"); 
include("news.php"); 
include("footer.php");

  ?>
  
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>
  