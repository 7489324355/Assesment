<?php 
session_start();
include("h2.php");
include 'Admin/connect.php';
$id = $_GET['MnoQtyPXZORTE'];
$message = $Home = '';
$_SESSION['staff'] = $id;
if ($_SESSION['staff'] == '') {
		header("location:forgotpass.php");
}
else
{
if(isset($_POST['submit'])) {
	$password = $_POST['password'];
	$Repassword = $_POST['Repassword'];

	if ($password !== $Repassword) {
		$message = "<div class='alert alert-danger'>Password Not Match..!!</div>";
	}
	else{
	$id_decode = base64_decode($id);
	$query = "UPDATE db_users SET password = '$password' WHERE id = '$id_decode' ";
	$result = $cn->query($query);
		if($result){
			$message = "<div class='alert alert-success'>Reset Your Password Successfully..</div>";
			$Home = "<a href='signin.php' class='btn btn-success btn-sm'>Login</a>";
	}else{
		$message = "<div class='alert alert-danger'>Failed to Reset Password..!!</div>";
	}
	}
}
}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>forget Password</title>


</head>
<body class="bg-secondary">
		<div class="container w-50 mt-5" >
			<form class="bg-light p-5 shadow-lg" method="post" style="margin-top:150px;">
				<?php echo $message; ?>
				<h1 class="text-success">Forget Password</h1>
				<label for="password">Password</label>
				<input type="text" name="password" placeholder="Password" class="form-control form-control-sm" required><br>
				<label for="password">Retype Password</label>
				<input type="text" name="Repassword" placeholder="Retype Password" class="form-control form-control-sm" required><br>
				<button type="submit" name="submit" class="btn btn-success btn-sm">Reset Password</button> <?php echo $Home; ?>
			</form>
		</div>
</body>
</html>