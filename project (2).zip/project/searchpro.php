<?php 
session_start(); 

include("Admin/connect.php");
include("h1.php");

$resident_type=$_POST['txtkeyword'];
$status=$_POST['type'];
$city_id=$_POST['city'];
$Beds=$_POST['beds'];
$Garages=$_POST['garages'];
$Baths=$_POST['baths'];
$price=$_POST['price'];

$q1="select * from db_resident_types where resident_type like '$resident_type'";
$res=mysqli_query($cn,$q1);

$row=mysqli_fetch_object($res);
$resident_id=$row->id;
echo "<br><br><br><br><br><br><br><br>".$q="select * from db_properties where status like '$status' and city_id=$city_id and Beds=$Beds and Garages=$Garages and Baths=$Baths and price=$price and resident_id=$resident_id";
$res=mysqli_query($cn,$q);
?>

  <main id="main">

    <!-- ======= Intro Single ======= -->
    <section class="intro-single">
      <div class="container">
        <div class="row">
          <div class="col-md-12 col-lg-8">
            <div class="title-single-box">
              <h1 class="title-single">Our Amazing Properties</h1>
              <span class="color-text-a">Grid Properties</span>
            </div>
          </div>
          <div class="col-md-12 col-lg-4">
            <nav aria-label="breadcrumb" class="breadcrumb-box d-flex justify-content-lg-end">
              <ol class="breadcrumb">
                <li class="breadcrumb-item">
                  <a href="#">Home</a>
                </li>
                <li class="breadcrumb-item active" aria-current="page">
                  Properties Grid
                </li>
              </ol>
            </nav>
          </div>
        </div>
      </div>
    </section><!-- End Intro Single-->

    <!-- ======= Property Grid ======= -->
    <section class="property-grid grid">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="grid-option">
              <form>
                <select class="custom-select">
                  <option selected>All</option>
                  <option value="1">New to Old</option>
                  <option value="2">For Rent</option>
                  <option value="3">For Sale</option>
                </select>
              </form>
            </div>
          </div>
          

<?php
while($row=mysqli_fetch_object($res)){
  ?>
<div class="col-md-4">
            <div class="card-box-a card-shadow">
              <div class="img-box-a">
                <img src="Admin/img/<?php echo $row->propertyimage ?>" alt="" class="img-a img-fluid">
              </div>
              <div class="card-overlay">
                <div class="card-overlay-a-content">
                  <div class="card-header-a">
                    <h2 class="card-title-a">
                      <a href="#"><?php $cid=$row->society_id;  
		$q3="select * from db_society  where id=".$cid;
		$res3=mysqli_query($cn,$q3);
		$row3=mysqli_fetch_object($res3);
		echo $row3->society_name;
		 ?> 
		
         <br /> <?php $cid=$row->area_id;  
		$q2="select * from db_area  where id=".$cid;
		$res2=mysqli_query($cn,$q2);
		$row2=mysqli_fetch_object($res2);
		echo $row2->areaname;
		 ?>	 </a>
                    </h2>
                  </div>
                  <div class="card-body-a">
                    <div class="price-box d-flex">
                      <span class="price-a">rent | $ <?php echo $row->price ?></span>
                    </div>
                    <a href="prosingle.php?id=<?php echo  $row-> id; ?>" class="link-a">Click here to view
                      <span class="bi bi-chevron-right"></span>
                    </a>
                  </div>
                  <div class="card-footer-a">
                    <ul class="card-info d-flex justify-content-around">
                      <li>
                        <h4 class="card-info-title">Area</h4>
                        <span><?php echo $row-> size ?>
                          <sup>2</sup>
                        </span>
                      </li>
                      <li>
                        <h4 class="card-info-title">Beds</h4>
                        <span><?php echo $row->Beds ?></span>
                      </li>
                      <li>
                        <h4 class="card-info-title">Baths</h4>
                        <span><?php echo $row->Baths ?></span>
                      </li>
                      <li>
                        <h4 class="card-info-title">Garages</h4>
                        <span><?php echo $row->Garages ?></span>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <?php
}
?>





</section><!-- End Property Grid Single-->

  </main><!-- End #main -->

 
  

<?php 
  include("footer.php");
  ?>