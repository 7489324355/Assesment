<?php 
// session_start(); 
include("h1.php");
include("Admin/connect.php");

$q="select * from db_users where email like'".$_SESSION['staff']."'"; 
$res=mysqli_query($cn,$q);
$row=mysqli_fetch_object($res);
$uid=$row->id;



 $q1="select * from db_properties where user_id =$uid";  
$res1=mysqli_query($cn,$q1);



           
   
?>
<style>
    

    body{
			 background-repeat:no-repeat; 
			 background-size: cover; 
			 background-position: center center; 
           
		}
  





</style>
<body background="a.jfif">


                        <form  method="post" class="" enctype="multipart/form-data">
                        <section class="panel">
                            
                        <div class="col-lg-9 col-md-12 col-xs-12 pl-0 user-dash2">
                        <div class="my-properties">
              

              <table style="margin-top:150px"  class="display table table-striped table-advance table-hover" id="documentstbl">
			  <thead>
			  <tr>
                   
                      <th class="pl-2">My Properties</th>
                      <th class="p-0"></th>
                    
                      <th>Date Added</th>
					  <th> ACTION </th>
                      </tr>
					</thead>
					</tr>
                    <?php
 while($row1=mysqli_fetch_object($res1)){
  ?>  
                                <tbody>
                                    <tr>
                                        <td class="image myelist">
                                            <a><img alt="my-properties-3" src="Admin/img/<?php echo $row1->propertyimage ?>" width="80px" height="70px" class="img-fluid"></a>
                                        </td>
                                        <td>
                                            <div class="inner">
                                                <a href="single-property-1.html"><h2><?php $cid=$row1->city_id;  
		$q3="select * from db_city  where id=".$cid;
		$res3=mysqli_query($cn,$q3);
		$row3=mysqli_fetch_object($res3);
		echo $row3->city_name;
		 ?> </h2></a>
                                                <figure><i class="lni-map-marker"></i> <?php $cid=$row1->society_id;  
		$q3="select * from db_society  where id=".$cid;
		$res3=mysqli_query($cn,$q3);
		$row3=mysqli_fetch_object($res3);
		echo $row3->society_name;
		 ?> , <?php $cid=$row1->area_id;  
         $q2="select * from db_area  where id=".$cid;
         $res2=mysqli_query($cn,$q2);
         $row2=mysqli_fetch_object($res2);
         echo $row2->areaname;
          ?></figure>
          
                                                
          
    
           <ul class="starts text-left mb-0">
 </ul>
             
        
        <!-- other columns here -->
    

                                                    

                                            </div>
                                            
                                          </td>
                                        <td><?php echo $row1->date ?></td>
                                        
                                      
                                        <td class="actions">

                                        
                                            <a href="editproperty.php?id=<?php echo $row1->id ?>" class="edit"><i class="lni-pencil"></i>Edit</a>

                                           <a  class=""   href="pro_del.php?id=<?php echo $row1->id;?>" onclick="return confirm('Are you sure want to delete???')"><i class="bi bi-trash"></i></a>
                                           
                                        </td>
                                    </tr>
                                    <?php
}
?>  

</form>
</section> 

</body>
</html> 
   
                                
                            