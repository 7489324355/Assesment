<?php 
'error_reporting';
include("Admin/connect.php");
$d="select *  from db_properties where id=".$_GET['id']; 
$res=mysqli_query($cn,$d);
$row=mysqli_fetch_object($res);
$q1="delete  from db_properties where id=".$_GET['id'];
$res1=mysqli_query($cn,$q1);
header("location:manage-pro.php");


?>