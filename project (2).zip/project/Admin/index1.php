<?Php  


include("connect.php");
//include("sessioncheck.php");



//  include 'sidebar.php'; 
 
?>
<html>
<head></head>

<body>

    <!-- <main class="app-content"> -->
        <!-- <div class="app-title"> --> -->
            <!-- <div> -->
                <!-- <h1><i class="fa fa-dashboard"></i> Dashboard Details</h1> -->
                <!-- <p>Start a beautiful journey here</p> -->
                
            <!-- </div> -->
            <!-- <ul class="app-breadcrumb breadcrumb"> -->
                <!-- <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li> -->
                <!-- <li class="breadcrumb-item"><a href="#"> Dashboard</a></li> -->
           
            <!-- </ul> -->
           
          
  <!-- </div> -->
  <h1 style="margin-left:300px;"><i class="fa fa-dashboard"></i> Dashboard Details</h1>
  
  <?php
            include 'dashboard.php';
?>
    <!-- </main> -->
    
</body>
</html>

