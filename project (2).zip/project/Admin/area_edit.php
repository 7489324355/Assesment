<?php 
include("connect.php");

include("sidebar.php");
$q1="select * from db_area  where id=".$_GET['id'];
$res1=mysqli_query($cn,$q1);
$row1=mysqli_fetch_object($res1);
if(isset($_REQUEST['btnsubmit']))
{
    
   
      $q="
      update db_area set
      areaname='".$_REQUEST['txtareaname']."',
	  city_id='".$_REQUEST['city']."'
      where id=".$_GET['id'];
         
    mysqli_query($cn,$q);     
    echo "<Script Lang=javascript>"; 
echo "window.location.href = 'viewarea.php' "; 
echo "</script>";
}
$cid= $row1->city_id;
					echo $q2="select * from db_city  where id=".$cid;
					$res2=mysqli_query($cn,$q2);
					$row2=mysqli_fetch_object($res2);
					


?>

<html>

<head>
<body>
   <main class="app-content">
    
		<div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                Basic Forms
              </header>
              <div class="panel-body">
			  <form role="form" method="post">
			  <form role="form" method="post">
                    <div class="form-group">
					<label for="">City</label>
					<select name="city" class="form-control"  >
                      
                    <?php 
					echo "<option value=".$row2-> id.">".$row2->city_name."</option>";
					
					$q="select * from db_city where id !=".$cid;
                     $res=mysqli_query($cn,$q);
					 
        while($row=mysqli_fetch_object($res))
        {
            echo "<option value=".$row-> id.">".$row->city_name."</option>";
        }
        ?>
                    </select> 
                  </div>
							
                        
                    						
                  <div class="form-group">
						<label for="Name">Area</label>
							<input type="text" class="form-control" value="<?php echo $row1->areaname; ?>"  name="txtareaname" required>								
                  </div>
				
		 <button type="submit" class="btn btn-info"name="btnsubmit">Update</button>
  <!-- <button  class="btn btn-primary"onClick="history.go(-1)">Back</button> -->
  <a href="viewarea.php" class="btn btn-dark">Back</a>
  
</form>
</body>
</html>
