<?php 
session_start();
session_destroy();
echo "<Script Lang=javascript>"; 
	echo "window.location.href = 'index.php' "; 
	echo "</script>";

?>