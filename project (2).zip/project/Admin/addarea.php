<?php
include("connect.php");
include("sidebar.php");  

if(isset($_REQUEST['save']))
    {                  
   		$q="insert into db_area set
         areaname='".$_REQUEST['areaname']."' ,
		  city_id='".$_REQUEST['city']."' 
	                 ";
              mysqli_query($cn,$q);

echo "<Script Lang=javascript>"; 
echo "window.location.href = 'viewarea.php' "; 
echo "</script>";
        
         
    }
?>
<html>

<head>
<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous"> -->
<body>
   <main class="app-content">
    
		<div class="row">
          <div class="col-lg-12">
		  <h3 class="page-header"><i class="fa fa-file-text-o"></i> ADD AREA</h3>
            <section class="panel">
              <header class="panel-heading">
			 
                Basic Forms
              </header>
              <div class="panel-body">
			  <form role="form" method="post">
                    <div class="form-group">
						 <label for="exampleInputcity">City</label>
                    <select name="city" class="form-control">
                      <option value="">Select City</option>
                    <?php 
					$q="select * from db_city";
                     $res=mysqli_query($cn,$q);
					 
        while($row=mysqli_fetch_object($res))
        {
            echo "<option value=".$row-> id.">".$row->city_name."</option>";
        }
        ?>
                    </select> 
                  </div>
				  
                  <div class="form-group">
						<label for="">Area</label>
							<input type="text" class="form-control" placeholder="Enter Area" name="areaname" required>								
                  </div>
				
                    
                 
                  <div class="col-md-12">
                     <button class="btn btn-info" name="save" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Add</button>&nbsp;&nbsp;&nbsp;
                        <a class="btn btn-secondary" onclick="javascript:history.go(-1);" href="sidebar.php"><i class="fa fa-fw fa-lg fa-times-circle"></i> Cancel</a>
                  </div> 
                </form>
          </div>
              </section> 
        </div>
		</main>
		
</body>

</html>