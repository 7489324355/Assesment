<?php 
include("connect.php");
include("sidebar.php");  
$q="select * from db_rating where id=".$_GET['id'];
$res=mysqli_query($cn,$q);
$row=mysqli_fetch_object($res);
// $row=mysqli_fetch_object($res);
// $img=$row->propertyimage;
?>
<html lang="en">
<head>

<!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet"> -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.6.4.js" integrity="sha256-a9jBBRygX1Bh5lt8GZjXDzyOB+bWve9EiO7tROUtj/E=" crossorigin="anonymous"></script>
</head>
<body>
   <main class="app-content">
 
 <div class="row">
          <div class="col-lg-12">
		  <h3 class="page-header"><i class="fa fa-table"></i>REVIEW TEBLE</h3>
            <section class="panel">
              <header class="panel-heading">
                Advanced Table
              </header>
              <form role="form" method="post">

              <table   class="display table table-striped table-advance table-hover" id="documentstbl">
                   <thead>
			  <tr>
              <div class="form-group">
                                <label style="margin-left:40px;  margin-top:30px;">Property ID</label>
                                <label style="margin-left:250px;  margin-top:30px;">Full Name</label>

                                <input style="width:200px; margin-left:120px;  margin-top:-30px;"  name="" class="form-control" value="<?php $cid=$row->properties_id;  
		$q1="select * from db_properties  where id=".$cid;
		$res1=mysqli_query($cn,$q1);
		$row1=mysqli_fetch_object($res1);
		echo $row1->id;
		 ?>">
                                <input style="width:200px; margin-left:430px;  margin-top:-35px;"  name="" class="form-control" value="<?php $cid=$row->user_id;  
		$q1="select * from db_users  where id=".$cid;
		$res1=mysqli_query($cn,$q1);
		$row1=mysqli_fetch_object($res1);
		echo $row1->name;
		 ?>">
                                <br>
                                <label style="margin-left:40px;  margin-top:10px;">Rating</label>
                                <label style="margin-left:280px;  margin-top:10px;">Date</label>

                                <input style="width:200px; margin-left:100px;  margin-top:-30px;"  name="" class="form-control" value="<?php echo $row->rating; ?>">
                                <input style="width:200px; margin-left:430px;  margin-top:-35px;"  name="" class="form-control" value="<?php echo $row->date; ?>">
                                <br>
                                <label style="margin-left:40px;  margin-top:10px;">Message</label>
                              

                                <input style="width:600px; height:50px; margin-left:100px;  margin-top:-30px;"  name="" class="form-control" value="<?php echo $row->message; ?>">
                                <br>
                                <label style="margin-left:40px;  margin-top:10px;">Photo</label>
                              

                                <!-- <input style="width:600px; height:50px; margin-left:100px;  margin-top:-30px;"  name="" class="form-control" value=""> -->
                                <img style="margin-left:40px;" src="img/<?php echo $row->photo; ?>" width="80" height="80">
                                <br>
                               <div>
                               <label style="margin-left:40px;  margin-top:30px;">Remark</label>
                               <input style="width:600px; height:50px; margin-left:100px;  margin-top:-30px;" placeholder="not update yet" name="" class="form-control" value="<?php echo $row->status; ?>">
                            </div>
                            <div>
                            <button type="button" style="margin-left:60px;" class = "btn btn-primary " data-bs-toggle="modal" data-bs-target="#editmodal" >Take Action</button>
                          
</div>
					  
                    </thead>
			  </tr>
                  
                      
              </table>
            </section>
          </div>
        </div>
		</main>
</form>	


<div class="modal" id="editmodal" >
  <div class="modal-dialog">
    <div class="modal-content">

      <!-- Modal Header -->

      <div class="modal-header">
        <h4 class="modal-title">Update Data </h4>
      </div>

      <!-- Modal body -->
      <div class="modal-body">
        <input type="text" id="hidden_id" value="<?php echo $_GET['id'];?>">

        <label>Status</label>
        <select id="status">
          <option value="approve">Approve</option>
          <option value="unapprove">Unapprove</option>
        </select>


      </div>
      <!-- Modal footer -->
      <div class="modal-footer">
        <button type="button" class="btn btn-success" onclick="updaterecord()">Save</button>
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>


      </div>
    </div>
  </div>
</div>



<script>
  

  function updaterecord() {
  
    var status = $("#status").val();
   var hidden_id = $("#hidden_id").val();
    console.log(status);

    $.ajax({
      url: 'update.php',
      method: "post",
      data: {  
        update_status:status,
        update_hidden:hidden_id
      },
      success: function (data, status) {
        alert(data);
        $("#editmodal").modal("hide");   
      }
    });
  }
</script>

</body>

</html>