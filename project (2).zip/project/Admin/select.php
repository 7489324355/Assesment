
<?php 
include("connect.php");
include("sidebar.php");  
$q="select * from db_rating where id=".$_GET['id'];
$res=mysqli_query($cn,$q);
$row=mysqli_fetch_object($res);




?>




                               <select style="margin-left:100px ; width:200px;" name = "status"> status
                                    <option value = "">SELECT STATUS</option>
                                    <option value="SELL">SELL</option>
                                    <option value="RENT">RENT</option>
                                </select>
                                 <script>

                                    
    
    


    
   
     
</script>