<?php 
include("connect.php"); 
$q1="delete from db_properties_types where id=".$_GET['id'];
$res1=mysqli_query($cn,$q1);
echo "<Script Lang=javascript>"; 
echo "window.location.href = 'view_pro_type.php' "; 
echo "</script>";

?>