<?php 
include("connect.php");

include("sidebar.php");
$q1="select * from db_city  where id=".$_GET['id'];
$res=mysqli_query($cn,$q1);
$row=mysqli_fetch_object($res);
if(isset($_REQUEST['btnsubmit']))
{
    
   
      $q="
      update db_city set
      city_name='".$_REQUEST['txtcityname']."'
      where id=".$_GET['id'];
         
    mysqli_query($cn,$q);     
   echo "<Script Lang=javascript>"; 
echo "window.location.href = 'viewcity.php' "; 
echo "</script>";
}
?>

<html>

<head>
<body>
   <main class="app-content">
    
		<div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                Basic Forms
              </header>
              <div class="panel-body">
			  <form role="form" method="post">
			  <div class="form-group">
                      <label for="Name">City</label>
                      <input type="text" class="form-control" value="<?php echo $row->city_name; ?>"  placeholder="Enter city Name" name="txtcityname" required>    
                      </div>
		 <button type="submit" class="btn btn-info"name="btnsubmit">Update</button>
  <!-- <button  class="btn btn-primary"onClick="history.go(-1)">Back</button> -->
  <a href="viewcity.php" class="btn btn-dark">Back</a>
</form>
</body>
</html>
