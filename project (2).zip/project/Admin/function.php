<?php
    function get_user_count(){
		include("connect.php");
					$user_count="";
	                $query = "select count(*) as user_count from  db_users where role_id=1";
	                $query_run = mysqli_query($cn, $query);
					while($row = mysqli_fetch_assoc($query_run)){
						$user_count = $row['user_count'];
					}
					return($user_count);
	}

    function get_seller_count(){
		include("connect.php");
					$seller_count="";
	                $query = "select count(*) as seller_count from  db_users where role_id=2";
	                $query_run = mysqli_query($cn, $query);
					while($row = mysqli_fetch_assoc($query_run)){
						$seller_count = $row['seller_count'];
					}
					return($seller_count);
	}

    function get_property_count(){
		include("connect.php");
					$property_count="";
	                $query = "select count(*) as property_count from  db_properties";
	                $query_run = mysqli_query($cn, $query);
					while($row = mysqli_fetch_assoc($query_run)){
						$property_count = $row['property_count'];
					}
					return($property_count);
	}

    function get_review_count(){
		include("connect.php");
					$review_count="";
	                $query = "select count(*) as review_count from  db_rating";
	                $query_run = mysqli_query($cn, $query);
					while($row = mysqli_fetch_assoc($query_run)){
						$review_count = $row['review_count'];
					}
					return($review_count);
	}

	function get_city_count(){
		include("connect.php");
					$city_count="";
	                $query = "select count(*) as city_count from  db_city";
	                $query_run = mysqli_query($cn, $query);
					while($row = mysqli_fetch_assoc($query_run)){
						$city_count = $row['city_count'];
					}
					return($city_count);
	}

	function get_booking_count(){
		include("connect.php");
					$booking_count="";
	                $query = "select count(*) as booking_count from  db_booking";
	                $query_run = mysqli_query($cn, $query);
					while($row = mysqli_fetch_assoc($query_run)){
						$booking_count = $row['booking_count'];
					}
					return($booking_count);
	}


	
?>