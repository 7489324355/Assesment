<?php 
session_start(); 
error_reporting(0);
include("connect.php");
//include("sessioncheck.php");

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="description" content="Techhive is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <title>DREAMHOUSE</title>
	<link rel="shortcut icon" href="../../IMG/MCA Logo1.png" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link href="css/dataTables.bootstrap.min.css" rel="stylesheet" > 
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
  </head>

  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
    <header class="app-header"><a class="app-header__logo" href="#">NICE ADMIN</a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
  
        <!--Notification Menu-->
        
        <!-- User Menu-->
       
<li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $_SESSION['staff'];?></a>
        <div class="dropdown-menu">
          <a class="dropdown-item " href="changepass.php">change Password</a>
          <a class="dropdown-item " href="index.php"  onclick="return confirm('Are you sure want to exit???')">Logout</a>

        </div>
      </li>
</ul>
      
    </header>
    <!-- Sidebar menu-->
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user">
        <div>
	      </div>
      </div>
      <ul class="app-menu">
	
		
      </ul>
    </aside> 
  </body>
   <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/main.js"></script>
  <script  src="js/bootstrap-datepicker.min.js"></script>
  <script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
   <script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/dataTables.bootstrap.min.js"></script>
	 <script type="text/javascript" src="js/jquery.PrintArea.js"></script>
    
 <script type="text/javascript">

      // Login Page Flipbox control
      $('.login-content [data-toggle="flip"]').click(function() {
        $('.login-box').toggleClass('flipped');
        return false;
      });
    </script>
</html>