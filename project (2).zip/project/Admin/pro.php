<?php 
include("connect.php");
include("sidebar.php");  
$q="select * from db_properties where id=".$_GET['id'];
$res=mysqli_query($cn,$q);
$row=mysqli_fetch_object($res);
//$q="select * from db_rating where id=".$_GET['id'];
//$res=mysqli_query($cn,$q);
//$row=mysqli_fetch_object($res);
// $row=mysqli_fetch_object($res);
// $img=$row->propertyimage;
?>


<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}
</style>
</head>
<body>
<main class="app-content">
 
 <div class="row">
          <div class="col-lg-12">
		  <h3 class="page-header"><i class="fa fa-table"></i>R TEBLE</h3>
            <section class="panel">
              <header style=" font-weight:bolder; color:blue;  font-size:20px; margin-left:350px;" class="panel-heading">
                Property Details
              </header>
              <form role="form" method="post" enctype="multipart/form-data">



<table style="width:100%" class="display table table-striped table-advance table-hover" id="documentstbl">
  <tr>
    <th style="width:20%" >User name</th>
    <td><?php $cid=$row->user_id;  
		$q1="select * from db_users  where id=".$cid;
		$res1=mysqli_query($cn,$q1);
		$row1=mysqli_fetch_object($res1);
		echo $row1->name;
		 ?></td>
  </tr>
  <tr>
    <th style="width:20%" >City</th>
    <td><?php $cid=$row->city_id;  
		$q1="select * from db_city  where id=".$cid;
		$res1=mysqli_query($cn,$q1);
		$row1=mysqli_fetch_object($res1);
		echo $row1->city_name;
		 ?></td>
  </tr>
  <tr>
    <th style="width:20%" >society</th>
    <td><?php $cid=$row->society_id;  
		$q3="select * from db_society  where id=".$cid;
		$res3=mysqli_query($cn,$q3);
		$row3=mysqli_fetch_object($res3);
		echo $row3->society_name;
		 ?></td>
  </tr>
  <tr>
    <th style="width:20%" >Area</th>
    <td><?php $cid=$row->area_id;  
		$q2="select * from db_area  where id=".$cid;
		$res2=mysqli_query($cn,$q2);
		$row2=mysqli_fetch_object($res2);
		echo $row2->areaname;
		 ?></td>
  </tr>
  <tr>
    <th style="width:20%" >Resident Type</th>
    <td><?php $cid=$row->resident_id;  
		$q1="select * from db_resident_types  where id=".$cid;
		$res1=mysqli_query($cn,$q1);
		$row1=mysqli_fetch_object($res1);
		echo $row1->resident_type;
		 ?></td>
  </tr>
  <tr>
    <th style="width:20%" >Property Type</th>
    <td><?php $cid=$row->properties_type_id;  
		$q1="select * from db_properties_types  where id=".$cid;
		$res1=mysqli_query($cn,$q1);
		$row1=mysqli_fetch_object($res1);
		echo $row1->property_type;
		 ?></td>
  </tr>
  <tr>
    <th style="width:20%" >Property Description</th>
    <td><?php echo $row-> property_des ?></td>
  </tr>
  <tr>
    <th style="width:20%" >Status</th>
    <td><?php echo $row-> status ?></td>
  </tr>
  <tr>
    <th style="width:20%" >Price</th>
    <td><?php echo $row-> price ?></td>
  </tr>
  <tr>
    <th style="width:20%" >Size</th>
    <td><?php echo $row-> size ?></td>
  </tr>
  <tr>
    <th style="width:20%" >Baths</th>
    <td><?php echo $row-> Baths ?></td>
  </tr>
  <tr>
    <th style="width:20%" >Beds</th>
    <td><?php echo $row-> Beds ?></td>
  </tr>
  <tr>
    <th style="width:20%" >Garages</th>
    <td><?php echo $row-> Garages ?></td>
  </tr>
 

  
</table>
<header style=" font-weight:bolder; color:blue;  font-size:20px; margin-left:350px;" class="panel-heading">
                GALLARY
              </header>
<table  style="width:100%" >
<tr>
    <th style="width:20% ;height:100px;" >Featured Image</th>
    <td><img style="margin-left:50px;" src="img/<?php echo $row->propertyimage; ?>" width="90" height="90"></td>
  </tr>
  <tr>
    <th style="width:20% ;height:100px;" >Gallary Image1</th>
    <td><img style="margin-left:50px;" src="img/<?php echo $row->g1; ?>" width="90" height="90"></td>
  </tr>
  <tr>
    <th style="width:20% ;height:100px;" >Gallary Image2</th>
    <td><img style="margin-left:50px;" src="img/<?php echo $row->g2; ?>" width="90" height="90"></td>
  </tr>
 <tr>
    <th style="width:20% ;height:100px;" >Gallary Image3</th>
    <td><img style="margin-left:50px;" src="img/<?php echo $row->g3; ?>" width="90" height="90"></td>
  </tr>
  <tr>
    <th style="width:20% ;height:100px;" >Gallary Image4</th>
    <td><img style="margin-left:50px;" src="img/<?php echo $row->g4; ?>" width="90" height="90"></td>
  </tr>
  <tr>
    <th style="width:20% ;height:100px;" >Gallary Image5</th>
    <td><img style="margin-left:50px;" src="img/<?php echo $row->g5; ?>" width="90" height="90"></td>
  </tr>

  <tr>
    <th style="width:20% ;height:100px;">Video</th>
    <td>
      <video controls autoplay>
      <source type="video/mp4" style="margin-left:50px;" src="img/<?php echo $row->video; ?>" width="90" height="90"></td>
</video>
  </tr>
</table>

<header style=" font-weight:bolder; color:blue;  font-size:20px; margin-left:350px;" class="panel-heading">
                Property Features
              </header>


              <?php 
              $features= explode(",",$row-> feature);
              ?>



<table  style="width:100%" >
<tr>
    <th style="width:80% ;" >center cooling</th>
    <?php 
    if(in_array("center cooling",$features)){
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" checked value="<?php echo $row-> feature ?>"></td>  
      <?php 
    }
    else
    {
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="<?php echo $row-> feature ?>"></td>
  
      <?php 
    }
    ?>
  </tr>
  <tr>
    <th style="width:20% ;" >Balcony</th>
    <?php 
    if(in_array("Balcony",$features)){
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" checked value="<?php echo $row-> feature ?>"></td>  
      <?php 
    }
    else
    {
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="<?php echo $row-> feature ?>"></td>
  
      <?php 
    }
    ?>
    
  </tr>
  <tr>
    <th style="width:20% ;" >Pet Friendly</th>
    <?php 
    if(in_array("Pet Friendly",$features)){
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" checked value="<?php echo $row-> feature ?>"></td>  
      <?php 
    }
    else
    {
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="<?php echo $row-> feature ?>"></td>
  
      <?php 
    }
    ?>
   
  </tr>
 <tr>
    <th style="width:20% ;" >Barbeque</th>
    <?php 
    if(in_array("Barbeque",$features)){
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" checked value="<?php echo $row-> feature ?>"></td>  
      <?php 
    }
    else
    {
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="<?php echo $row-> feature ?>"></td>
  
      <?php 
    }
    ?>
   
  </tr>
  <tr>
    <th style="width:20% ;" >Fire Alarm</th>
    <?php 
    if(in_array("Fire Alarm",$features)){
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" checked value="<?php echo $row-> feature ?>"></td>  
      <?php 
    }
    else
    {
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="<?php echo $row-> feature ?>"></td>
  
      <?php 
    }
    ?>
   
  </tr>
  <tr>
    <th style="width:20% ;" >Modern Kitchen</th>
    <?php 
    if(in_array("Modern Kitchen",$features)){
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" checked value="<?php echo $row-> feature ?>"></td>  
      <?php 
    }
    else
    {
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="<?php echo $row-> feature ?>"></td>
  
      <?php 
    }
    ?>
   
  </tr>

  <tr>
    <th style="width:20% ;" >Storage</th>
    <?php 
    if(in_array("Storage",$features)){
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" checked value="<?php echo $row-> feature ?>"></td>  
      <?php 
    }
    else
    {
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="<?php echo $row-> feature ?>"></td>
  
      <?php 
    }
    ?>
  
  </tr>

  <tr>
    <th style="width:20% ;" >Dryer</th>
    <?php 
    if(in_array("Dryer",$features)){
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" checked value="<?php echo $row-> feature ?>"></td>  
      <?php 
    }
    else
    {
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="<?php echo $row-> feature ?>"></td>
  
      <?php 
    }
    ?>
 
  </tr>
  <tr>
    <th style="width:20% ;" >Heating</th>
    <?php 
    if(in_array("Heating",$features)){
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" checked value="<?php echo $row-> feature ?>"></td>  
      <?php 
    }
    else
    {
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="<?php echo $row-> feature ?>"></td>
  
      <?php 
    }
    ?>
   
  </tr>
  <tr>
    <th style="width:20% ;">Pool</th>
    <?php 
    if(in_array("Pool",$features)){
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" checked value="<?php echo $row-> feature ?>"></td>  
      <?php 
    }
    else
    {
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="<?php echo $row-> feature ?>"></td>
  
      <?php 
    }
    ?>
   
  </tr>
  <tr>
    <th style="width:20% ;" >Laundry</th>
    <?php 
    if(in_array("Laundry",$features)){
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" checked value="<?php echo $row-> feature ?>"></td>  
      <?php 
    }
    else
    {
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="<?php echo $row-> feature ?>"></td>
  
      <?php 
    }
    ?>
   
  </tr>
  <tr>
    <th style="width:20% ;" >Sauna</th>
    <?php 
    if(in_array("Sauna",$features)){
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" checked value="<?php echo $row-> feature ?>"></td>  
      <?php 
    }
    else
    {
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="<?php echo $row-> feature ?>"></td>
  
      <?php 
    }
    ?>
   
  </tr>
  <tr>
    <th style="width:20% ;" >Gym</th>
    <?php 
    if(in_array("Gym",$features)){
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" checked value="<?php echo $row-> feature ?>"></td>  
      <?php 
    }
    else
    {
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="<?php echo $row-> feature ?>"></td>
  
      <?php 
    }
    ?>
    
  </tr>
  <tr>
    <th style="width:20% ;" >Elevator</th>
    <?php 
    if(in_array("Elevator",$features)){
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" checked value="<?php echo $row-> feature ?>"></td>  
      <?php 
    }
    else
    {
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="<?php echo $row-> feature ?>"></td>
  
      <?php 
    }
    ?>
   
  </tr>
  <tr>
    <th style="width:20% ;" >Dish Washe</th>
    <?php 
    if(in_array("Dish Washe",$features)){
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" checked value="<?php echo $row-> feature ?>"></td>  
      <?php 
    }
    else
    {
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="<?php echo $row-> feature ?>"></td>
  
      <?php 
    }
    ?>
  
  </tr>
  <tr>
    <th style="width:20% ;" >Emergency Exit</th>
    <?php 
    if(in_array("Emergency Exit",$features)){
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]" checked value="<?php echo $row-> feature ?>"></td>  
      <?php 
    }
    else
    {
      ?>
      <td> <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="<?php echo $row-> feature ?>"></td>
  
      <?php 
    }
    ?>
    
  </tr>
</table>
</form>
</body>
</html>
