<?php 
include("connect.php");
include("sidebar.php");  
$q="select * from db_rating where status='unapprove'";
$res=mysqli_query($cn,$q);
// $row=mysqli_fetch_object($res);
// $img=$row->propertyimage;
?>
<html lang="en">
<head>
<script>
$(document).ready(function() {
    $('#documentstbl').DataTable();
} );
</script>
</head>
<body>
   <main class="app-content">
 
 <div class="row">
          <div class="col-lg-12">
		  <h3 class="page-header"><i class="fa fa-table"></i>REVIEW TEBLE</h3>
            <section class="panel">
              <header class="panel-heading">
                Advanced Table
              </header>

              <table   class="display table table-striped table-advance table-hover" id="documentstbl">
                   <thead>
			  <tr>
                      <th>ID </th>
                      <th> user name </th>
                      <th>Property_id </th>
					  <th>Rating</th>
					  <th>Review Date</th>
                     
                   
					  
                    </thead>
			  </tr>
                     <?php 
    while($row=mysqli_fetch_object($res))
    {
    ?>
    <tr>
	    <td><?php echo $row->id;  ?></td>
      <td><?php $cid=$row->user_id;  
		$q1="select * from db_users  where id=".$cid;
		$res1=mysqli_query($cn,$q1);
		$row1=mysqli_fetch_object($res1);
		echo $row1->name;
		 ?></td>

         <td><?php $cid=$row->properties_id;  
		$q1="select * from db_properties  where id=".$cid;
		$res1=mysqli_query($cn,$q1);
		$row1=mysqli_fetch_object($res1);
		echo $row1->id;
		 ?></td>
         <td>
         <?php 
                                                        
                                                        if($row->rating==1){
                                                                echo '<i class="fa fa-star"  style="color:#ffc700;">★ </i>';
                                                                echo '<i class="fa fa-star"  style="color:#999999;">★</i>';
                                                                echo '<i class="fa fa-star"  style="color:#999999;">★</i>';
                                                                echo '<i class="fa fa-star"  style="color:#999999;">★</i>';
                                                                echo '<i class="fa fa-star"  style="color:#999999;">★</i>';
                                                        }
                                                        else if($row->rating==2){
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#999999;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#999999;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#999999;">★</i>';
                                                        }
                                                        else if($row->rating==3){
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#999999;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#999999;">★</i>';
                                                        }
                                                        else if($row->rating==4){
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#999999;">★</i>';
                                                        }
                                                        else if($row->rating==5){
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★ </i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                            echo '<i class="fa fa-star" style="color:#ffc700;">★</i>';
                                                        }
                                                        
                                                        ?>
                                                        </td>
         <td><?php echo $row->date;?></td>
	 
         
    </tr>
                   
    <?php 
    }
    ?>
                      
              </table>
            </section>
          </div>
        </div>
		</main>
		
</body>

</html>