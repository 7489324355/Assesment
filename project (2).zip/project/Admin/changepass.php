<?Php 
session_start();

error_reporting(0);
include('connect.php');
include('sessioncheck.php');
//include('header.php');
//include('sidebar.php');
$err="";



if(isset($_POST['btnsubmit']))
{
		$op=($_POST['password0']);
		$sqlselect = "select * from db_users where email like '".$_SESSION['staff']."' and password like '".$op."'";
		$resselect = mysqli_query($cn,$sqlselect);
		if(mysqli_num_rows($resselect) > 0)
		{
			if($_POST['password1']==$_POST['password2'])
			{
				$np=($_POST['password1']);
				$sqlupdate = "update db_users set password='".$np."' where email like '".$_SESSION['staff']."'";
			mysqli_query($cn,$sqlupdate);
			echo "<script>alert('Password changed Successfully');</script>";
			echo "<script>location.href='sidebar.php?res=change';</script>";
			}
			else
			{
				echo "<script>alert('New and Confirm password did not match...');</script>";
			}
			
		}
		else
		{
			echo "<script>alert('Invalid Old Password..');</script>";
		}
}
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="CS/css/bootstrap.min.css"> 
  <link href="CS/css/font-awesome.min.css" rel="stylesheet"> 
   <link href="CS/css/main.css" rel="stylesheet" > 
   <link href="CS/css/custom.css" rel="stylesheet" > 
<link rel="shortcut icon" href="../IMG/MCA Logo1.png" />
    <title>VTCBCSR</title>
    <style type="text/css">
    
    
   form{
    margin-top: 40px;
    text-align:left;
    margin-left:150px;
    margin-right:150px;
   }
  
   
  
   .login-head{
   
     text-align:center;
     font-size:50px;
     margin-top: 90px;
     font-weight:bolder;
     color:blue;
   
    }
  
  
   
    </style>
  </head>
  <body>
 
   <!-- <section class="material-half-bg">
      <div class="cover"></div>
    </section> -->
   <!-- <section class="login-content"> -->
      <div class="logo">
      <h3 class="login-head"><i class="fa fa-lg fa-fw fa-lock"></i>Change Password ?</h3>
      </div>
     
  
       

      <div class="login-box">
        <form class="login-form" method="post" >
        
          <div class="form-group">
            <label class="control-label">Old Passsword</label>
            <input class="form-control" type="password"  required  placeholder="Old password" name="password0">
          </div>
          <div class="form-group">
            <label class="control-label">New Password</label>
            <input class="form-control" type="password" required  name="password1" placeholder="New Password">
          </div>
          <div class="form-group">
            <label class="control-label">Confirm Password</label>
            <input class="form-control" type="password" required  name="password2" placeholder="Confirm Password">
          </div>
		   <div class="form-group">
            <div class="utility">
              <div class="animated-checkbox">
                
              </div>
              </div>
          </div>
          <div class="form-group btn-container">
            <button class="btn btn-primary " name="btnsubmit" type="submit"><i class="fa fa-sign-in fa-lg fa-fw"></i>Reset</button>
          
            <a href="index1.php" class="btn btn-dark">Back</a>
           
          
           
          </div>
          
        </form>
      
        </div>
      </div>
    </section> 
	
    <!-- Essential javascripts for application to work-->
    <script src="CS/js/jquery-3.2.1.min.js"></script>
    <script src="CS/js/popper.min.js"></script>
    <script src="CS/js/bootstrap.min.js"></script>
    <script src="CS/js/main.js"></script>    
    <script type="text/javascript">
      // Login Page Flipbox control
      $('.login-content [data-toggle="flip"]').click(function() {
      	$('.login-box').toggleClass('flipped');
      	return false;
      });
    </script>
  </body>
</html>
<?php 
include("../footer.php");
?>
