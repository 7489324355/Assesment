<?php 
include("connect.php");

include("sidebar.php");
$q1="select * from db_resident_types  where id=".$_GET['id'];
$res=mysqli_query($cn,$q1);
$row=mysqli_fetch_object($res);
if(isset($_REQUEST['btnsubmit']))
{
    
   
      $q="
      update db_resident_types set
      resident_type='".$_REQUEST['txtresidenttype']."'
      where id=".$_GET['id'];
         
    mysqli_query($cn,$q);     
   echo "<Script Lang=javascript>"; 
echo "window.location.href = 'viewresident.php' "; 
echo "</script>";
}
?>

<html>

<head>
<body>
   <main class="app-content">
    
		<div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                Basic Forms
              </header>
              <div class="panel-body">
			  <form role="form" method="post">
			  <div class="form-group">
                      <label for="Name">City</label>
                      <input type="text" class="form-control" value="<?php echo $row->resident_type; ?>"  placeholder="Enter resident_type " name="txtresidenttype" required>    
                      </div>
		 <button type="submit" class="btn btn-info"name="btnsubmit">Update</button>
  <!-- <button  class="btn btn-primary"onClick="history.go(-1)">Back</button> -->
  <a href="viewcity.php" class="btn btn-dark">Back</a>
</form>
</body>
</html>
