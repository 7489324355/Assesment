<?php 
include("connect.php");
include ("sidebar.php"); 
$q1="Select * from db_properties_types where id=".$_GET['id'];
$res1=mysqli_query($cn,$q1);
$row1=mysqli_fetch_object($res1);
if(isset($_REQUEST['save']))
    {                  
   		$q="update db_properties_types set
          property_type='".$_REQUEST['property_type']."'
		 where id=".$_GET['id'];
              mysqli_query($cn,$q);

 echo "<Script Lang=javascript>"; 
echo "window.location.href = 'view_pro_type.php' "; 
echo "</script>";

        
         
    }

?>

<html>
<head>
<body>
		<main class="app-content">
			<div class="col-lg-12">
				<section class="panel"
				<header class="panel-heading">
				Basic Form
				</header>
				<div class="panel-body">
				<form role="form" method="post">
					<div class="form-group">
						<label for="ExampleInputcity">Society</label>
							<input type="text" class="form-control" name="property_type" placeholder="Enter Property type" value="<?php echo $row1->property_type; ?>" required>
					</div>
					</div>
					
					<div class="col-md-12">
                     <button class="btn btn-primary" name="save" type="submit"><i class="fa fa-fw fa-lg fa-check-circle"></i>Update</button>&nbsp;&nbsp;&nbsp;
                        <a class="btn btn-dark"href="view_pro_type.php">Back</a>
                  </div> 
                </form>
          </div>
			</section>
		</div>
		</main>
</body>
</html>