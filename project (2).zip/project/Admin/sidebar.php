 <?php 
session_start(); 
error_reporting(0);
include("connect.php");
include("sessioncheck.php");

?>
 
 
 <!DOCTYPE html>
<html lang="en">
  <head>
    <meta name="description" content="Techhive is a responsive and free admin theme built with Bootstrap 4, SASS and PUG.js. It's fully customizable and modular.">
    <title>DREAMHOUSE</title>
	<link rel="shortcut icon" href="../../IMG/MCA Logo1.png" />
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Main CSS-->
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/main.css">
  <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link href="css/dataTables.bootstrap.min.css" rel="stylesheet" > 
    <!-- Font-icon css-->
    <link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
  </head>

  <body class="app sidebar-mini rtl">
    <!-- Navbar-->
    <header class="app-header"><a class="app-header__logo" href="#">Nice Admin</a>
      <!-- Sidebar toggle button--><a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
      <!-- Navbar Right Menu-->
      <ul class="app-nav">
  
        <!--Notification Menu-->
        
        <!-- User Menu-->
         <li class="dropdown"><a class="app-nav__item"  data-toggle="dropdown" aria-label="Open Profile Menu" ><img src = "img/adminimg.jpg" width="30" height="30"><?php echo $_SESSION['staff']; ?><i class='fa fa-angle-down' style="margin-left:10px; " ></i></i></a> 
          <ul class="dropdown-menu settings-menu dropdown-menu-right">
		    <li><a class="dropdown-item" href="changepass.php"><i class="fa fa-sign-out fa-lg"></i> Change Password</a></li>  
            <li><a class="dropdown-item" href="logout.php"  onclick="return confirm('Are you sure want to exit???')"><i class="fa fa-sign-out fa-lg"></i> Logout</a></li> 
          </ul>
        </li>
      </ul>
    </header>

 <!-- Sidebar menu-->
     <div class="app-sidebar__overlay" data-toggle="sidebar" style="color:white;"></div>
    <aside class="app-sidebar">
      <div class="app-sidebar__user">
        <div>
	      </div>
      </div>
        
     
      <!-- <ul class="app-menu dropdown"> -->
	    <li><a  class="app-menu__item" href="dashboard.php"><i class='fa fa-dashboard'></i><span class="app-menu__label" style="margin-left:20px;">Dashboard</span></a></li>
       
          <li class="dropdown" >
		  <a class="app-nav__item"  data-toggle="dropdown"><i class='fas fa-city' ></i><span class="app-menu__label" style="margin-left:20px; ">Manage City</span><i class='fa fa-angle-down' style="margin-left:20px;  "></i></a>
		 <ul class="dropdown-menu settings-menu dropdown-menu-right"> 
		 <div>
		     <a  class="dropdown-item" href="addcity.php">Add city</a>
		      <a  class="dropdown-item" href="viewcity.php"> View city</a>
		 </div>
		 </ul>
		 </li>
		 
		 <li class="dropdown" >
		 <a class="app-nav__item"  data-toggle="dropdown"><i class='fas fa-city' ></i><span class="app-menu__label" style="margin-left:20px; ">Manage Area</span><i class='fa fa-angle-down' style="margin-left:20px;  "></i></a>
		<ul class="dropdown-menu settings-menu dropdown-menu-right">
           <div>		
		<li><a  class="dropdown-item" href="addarea.php">Add area</a></li>
		 <li><a  class="dropdown-item" href="viewarea.php">View Area</a></li>
		 <div>
		  </ul> 
		  </li>
		  
		 <li class="dropdown" >
		  <a class="app-nav__item"  data-toggle="dropdown"><i class='fa fa-dedent' ></i><span class="app-menu__label" style="margin-left:20px; ">Manage Society</span><i class='fa fa-angle-down' style="margin-left:20px; " ></i></a>
		<ul class="dropdown-menu settings-menu dropdown-menu-right"> 
		<div>
		 <li><a  class="dropdown-item" href="add_society.php">Add Society</a></li>
		 <li><a  class="dropdown-item" href="view_society.php">View Society</a></li>
		 </div>
		  </ul> 
		  </li>
		  
		<li class="dropdown" >
		<a class="app-nav__item"  data-toggle="dropdown"><i class='fa fa-building' ></i><span class="app-menu__label" style="margin-left:20px; ">Manage resident</span><i class='fa fa-angle-down' style="margin-left:20px;"  ></i></a>
		<ul class="dropdown-menu settings-menu dropdown-menu-right">
        <div>		
		 <li><a  class="dropdown-item" href="add_resident.php">Add resident</a></li>
		 <li><a  class="dropdown-item" href="viewresident.php"> View resident</a></li>
		 </div>
		  </ul> 
		  </li>
		  
		  <li class="dropdown" >
		  <a class="app-nav__item"  data-toggle="dropdown"><i class='fas fa-house-user' ></i><span class="app-menu__label" style="margin-left:20px; ">Manage Propertytype<i class='fa fa-angle-down' style="margin-left:20px; " ></i></a>
		<ul class="dropdown-menu settings-menu dropdown-menu-right">
         <div>		
		 <li><a  class="dropdown-item" href="add_pro_type.php">Add Propertytype</a></li>
		 <li><a  class="dropdown-item" href="view_pro_type.php"> View Propertytype</a></li>
		 </div>
		  </ul> 
		  </li>

      <li><a  class="app-menu__item" href="buy.php"><i class='fa fa-user-friends' ></i><span class="app-menu__label" style="margin-left:20px; "> User</span></a></li>
		  
		  <li><a  class="app-menu__item" href="seller.php"><i class='fa fa-user-friends' ></i><span class="app-menu__label" style="margin-left:20px; ">Seller</span></a></li>

      <li class="dropdown" >
		<a class="app-nav__item"  data-toggle="dropdown"><i class='fa fa-star' ></i><span class="app-menu__label" style="margin-left:20px; ">Review</span><i class='fa fa-angle-down' style="margin-left:20px; " ></i></a>
		<ul class="dropdown-menu settings-menu dropdown-menu-right">
        <div>		
		 <li><a  class="dropdown-item" href="newreview.php">New Review</a></li>
		 <li><a  class="dropdown-item" href="approve.php">Approved Review</a></li>
     <li><a  class="dropdown-item" href="unapprove.php">Unapproved Review</a></li>
		 </div>
		  </ul> 
		  </li>
      
		  
		  <li><a  class="app-menu__item" href="viewproperty.php"><i class='fa fa-institution' ></i><span class="app-menu__label" style="margin-left:20px; ">Manage Properties</span></a></li>
		  
		  <li><a  class="app-menu__item" href="viewbooking.php"><i class='fas fa-thumbs-up' ></i><span class="app-menu__label" style="margin-left:20px; ">View booking</span></a></li>

      <!-- <li><a  class="app-menu__item" href="manageuser.php"><span class="app-menu__label">Manage User</span></a></li> -->
		  
		  </ul> 
		     
    </aside> 
	
  </body>
   <script type="text/javascript" src="js/jquery.min.js"></script>
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <script type="text/javascript" src="js/main.js"></script>
  <!-- <script  src="js/bootstrap-datepicker.min.js"></script> -->
  <script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
   <script type="text/javascript" src="js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="js/dataTables.bootstrap.min.js"></script>
	 <script type="text/javascript" src="js/jquery.PrintArea.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
 <script type="text/javascript">

      // Login Page Flipbox control
      $('.login-content [data-toggle="flip"]').click(function() {
        $('.login-box').toggleClass('flipped');
        return false;
      });
    </script>
</html>
	  
                          