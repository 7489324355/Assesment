<?Php 
//session_start();
//error_reporting(0);
include("h1.php");
include 'Admin/connect.php';

$u= $_SESSION['staff']; 
$q="select * from db_users where email like '$u'";
$res=mysqli_query($cn,$q);
$row=mysqli_fetch_object($res);
$uid=$row->id;



if(isset($_POST['add']))


    {   
        $brand = $_POST["brands"]  ;
        $lang=implode(",",$brand);             
   	echo 	$q="insert into db_properties set
          city_id='".$_REQUEST['city']."'  ,
          user_id='$uid'  ,
         area_id='".$_REQUEST['area']."'  ,
         society_id='".$_REQUEST['society']."'  ,
         resident_id='".$_REQUEST['resident_type']."'  ,
         properties_type_id='".$_REQUEST['property_type']."'  ,
		  status='".$_REQUEST['status']."',
          price='".$_REQUEST['price']."',
          size='".$_REQUEST['size']."',
          Beds='".$_REQUEST['Beds']."',
          Baths='".$_REQUEST['Baths']."',
          Garages='".$_REQUEST['Garages']."',
          property_des='".$_REQUEST['message']."',
            feature='$lang',

      propertyimage='".$_FILES['myfile']['name']."',
      g1='".$_FILES['img1']['name']."',
      g2='".$_FILES['img2']['name']."',
      g3='".$_FILES['img3']['name']."',
      g4='".$_FILES['img4']['name']."',
      g5='".$_FILES['img5']['name']."',
      video='".$_FILES['img6']['name']."'
      
 		  ";

       move_uploaded_file($_FILES['myfile']['tmp_name'],"admin/img/".$_FILES['myfile']['name']);
       move_uploaded_file($_FILES['img1']['tmp_name'],"admin/img/".$_FILES['img1']['name']);
       move_uploaded_file($_FILES['img2']['tmp_name'],"admin/img/".$_FILES['img2']['name']);
       move_uploaded_file($_FILES['img3']['tmp_name'],"admin/img/".$_FILES['img3']['name']);
       move_uploaded_file($_FILES['img4']['tmp_name'],"admin/img/".$_FILES['img4']['name']);
       move_uploaded_file($_FILES['img5']['tmp_name'],"admin/img/".$_FILES['img5']['name']);
       move_uploaded_file($_FILES['img6']['tmp_name'],"admin/img/".$_FILES['img6']['name']);

      
       $rs1 = mysqli_query($cn,$q);
        
         
      
            
            
     echo "<Script Lang=javascript>"; 
     echo "window.location.href = 'index2.php' "; 
     echo "</script>";
         
           
               
              //echo "<Script Lang=javascript>"; 
             // echo "window.location.href = 'index2.php' "; 
             // echo "</script>";
              
        
              

  
}

?>



<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    
<style type="text/css">
    
    
    
    
    
    h3{
        margin-top: 200px;
        font-size:40px;
        font-weight:bolder;
        color:orange;
        margin-left:400px;
     
    
     }
     h4{
       
        margin-top: 50px;
      font-size:25px;
      font-weight:bolder;
      color:black;
    
     }
    
    

    
     </style>
    
    
    
   
  
</head>
  <body>


<section class="contact-us">
            <div class="grid-container" >
            
                <div class="row">
                    <div class="row-lg-4">
                        <h3 class="mb-4">ADD PROPERTY</h3>
                        <form  method="post" class="" enctype="multipart/form-data">
                           
</div>
                        <div class="item-1">
                                <label style="margin-left:40px;">cityname</label>
                                <label style="margin-left:250px;">Area</label>
                                <label style="margin-left:250px;">societyname</label>
                                <br>
                                
                                
                                <select style="width:200px; margin-left:40px;" name="city" >
                                    <option value="">Select City</option>
                                        <?php 
                                              $q="select * from db_city";
                                                        $res=mysqli_query($cn,$q);
                                              
                                            while($row=mysqli_fetch_object($res))
                                            {
                                                echo "<option value=".$row-> id.">".$row->city_name."</option>";
                                            }
                                      ?>
                                </select>
    
                                
    
                               
                                <select style="margin-left:100px ; width:200px;" name="area">
                      <option value="">Area</option>
                    <?php 
					$q="select * from db_area";
                     $res=mysqli_query($cn,$q);
					 
        while($row=mysqli_fetch_object($res))
        {
            echo "<option value=".$row-> id.">".$row->areaname."</option>";
        }
        ?>
        </select>
                                
                           
                               
                                <select style="margin-left:100px ; width:200px;" name="society" >
                              
                      <option value="">SOCIETY_NAME</option>
                    <?php 
					$q="select * from db_society";
                     $res=mysqli_query($cn,$q);
					 
        while($row=mysqli_fetch_object($res))
        {
            echo "<option value=".$row-> id.">".$row->society_name."</option>";
        }
        ?>
        </select>
                               
                            </div>
                                 <div class="form-group">
                                <label style="margin-left:40px;  margin-top:30px;">resident_type</label>
                                <label style="margin-left:200px; margin-top:30px;"> propertytype</label>
                                <label style="margin-left:200px;  margin-top:30px;" for = "status"> status </label>
                                <br>
                                <select style="width:200px; margin-left:40px;" name="resident_type" >
                                    <option value="">SELECT RESIDENT_TYPE </option>
                                    <?php 
					$q="select * from db_resident_types";
                     $res=mysqli_query($cn,$q);
					 
        while($row=mysqli_fetch_object($res))
        {
            echo "<option value=".$row-> id.">".$row->resident_type."</option>";
        }
        ?>
                                </select>
                               
                           
                                
                                <select style="margin-left:100px ; width:200px;" name = "property_type">
                                <option value = "">PROPERTYTYPE</option>
                                <?php 
					$q="select * from db_properties_types";
                     $res=mysqli_query($cn,$q);
					 
        while($row=mysqli_fetch_object($res))
        {
            echo "<option value=".$row-> id.">".$row->property_type."</option>";
        }
        ?>
                            </select>
                            
                           
                               
                                <select style="margin-left:100px ; width:200px;" name = "status"> status
                                    <option value = "">SELECT STATUS</option>
                                    <option value="SELL">SELL</option>
                                    <option value="RENT">RENT</option>
                                </select>
                               
                           
                        
                               
                            </div>
                            <div class="form-group">
                                <label style="margin-left:40px;  margin-top:30px;" for = "price"> price</label>
                                <label   style="margin-left:280px;  margin-top:30px;" for = "size"> size</label>
                                <label  style="margin-left:280px;  margin-top:30px;" for = "Beds">Beds</label>
                                <br>
                                <input style="width:200px; margin-left:40px;"  type="text" class="form-control input-custom input-full" name="price" placeholder="" value  = "">
                                <input style="width:200px; margin-left:340px; margin-top:-39px;"  type="text"  class="form-control input-custom input-full" name="size" placeholder="sq. ft" value="">
                                <input style="width:200px; margin-left:650px;  margin-top:-39px;"  type="number"  class="form-control input-custom input-full" name="Beds" placeholder="" value="">
                              
                            </div>
                            <div class="form-group">
                                <label style="margin-left:40px;  margin-top:30px;" for = "Baths">Baths</label>
                                <label style="margin-left:280px;  margin-top:30px;" for = "Garages">Garages</label>
                                <label style="margin-left:250px;  margin-top:30px;" for = "Garages">Property Description</label>
                                <br>
                                <input style="width:200px; margin-left:40px;" type="number"  class="form-control input-custom input-full" name="Baths" placeholder="" value="">
                                <input style="width:200px; margin-left:340px; margin-top:-39px;" type="number"  class="form-control input-custom input-full" name="Garages" placeholder="" value="">
                                <textarea style="margin-left:650px; width:300px; margin-top:-39px;" id="textMessage" name="message" class="form-control" placeholder=""  cols="30" rows="3" required></textarea>
                              
                            </div>
                              <!-- <div class="form-group">
                                <label for = "size"> size</label>
                                <input type="text"  class="form-control input-custom input-full" name="size" placeholder="" value="">
                            </div> -->

                            <h4 class="mb-2"> PROPERTY FEATURE</h4>
                            
                            <div class="form-group">
                            
                            <input style="margin-left:40px;  margin-top:30px;" type="checkbox" name="brands[]"  value="center cooling" >center cooling
                            <input style="margin-left:200px;  margin-top:30px;" type="checkbox" name="brands[]"   value="Balcony">Balcony
                            <input style="margin-left:200px;  margin-top:30px;" type="checkbox" name="brands[]"  value="Pet Friendly">Pet Friendly
                            <input style="margin-left:200px;  margin-top:30px;" type="checkbox" name="brands[]"  value="Barbeque">Barbeque
                            <br>
                            <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="Fire Alarm">Fire Alarm
                            <input style="margin-left:225px;  margin-top:10px;" type="checkbox" name="brands[]"  value="Modern Kitchen" >Modern Kitchen
                            <input style="margin-left:147px;  margin-top:10px;" type="checkbox" name="brands[]"  value="Storage">Storage
                            <input style="margin-left:229px;  margin-top:10px;" type="checkbox" name="brands[]"  value="Dryer">Dryer
                            <br>
                            <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="Heating">Heating
                            <input style="margin-left:245px;  margin-top:10px;" type="checkbox" name="brands[]"  value="Pool">Pool
                            <input style="margin-left:225px;  margin-top:10px;" type="checkbox" name="brands[]"  value="Laundry">Laundry
                            <input style="margin-left:228px;  margin-top:10px;" type="checkbox" name="brands[]"  value="Sauna">Sauna
                            <br>
                            <input style="margin-left:40px;  margin-top:10px;" type="checkbox" name="brands[]"  value="Gym">Gym
                            <input style="margin-left:267px;  margin-top:10px;" type="checkbox" name="brands[]"  value="Elevator">Elevator
                            <input style="margin-left:198px;  margin-top:10px;" type="checkbox" name="brands[]"  value="Dish Washer">Dish Washer
                            <input style="margin-left:194px;  margin-top:10px;" type="checkbox" name="brands[]"  value=">Emergency Exit">Emergency Exit

    </div>
                            <h4 class="mb-2"> PROPERTY GALLARY</h4>
                              <div class="form-group">
                              <label style="margin-left:40px;  margin-top:30px;" for = "price">Feature Image:</label>
                              <label style="margin-left:300px;  margin-top:30px;" for = "price">Gallary Image1:</label>
                              <label style="margin-left:300px;  margin-top:30px;" for = "price">Gallary Image2:</label>
                              <br>
                                <input style="width:300px; margin-left:40px;" type="file" name="myfile"  class="form-control input-custom input-full">
                                <input style="width:300px; margin-left:450px; margin-top:-39px;" type="file" name="img1"  class="form-control input-custom input-full">
                                <input style="width:300px; margin-left:880px; margin-top:-39px;" type="file" name="img2"  class="form-control input-custom input-full">
                               

                                <label style="margin-left:40px;  margin-top:5px;" for = "price">Gallary Image3:</label>
                              <label style="margin-left:300px;  margin-top:5px;" for = "price">Gallary Image4:</label>
                              <label style="margin-left:300px;  margin-top:5px;" for = "price">Gallary Image5:</label>
                             
                              <br>
                                <input style="width:300px; margin-left:40px;" type="file" name="img3"  class="form-control input-custom input-full">
                                <input style="width:300px; margin-left:450px; margin-top:-39px;" type="file" name="img4"  class="form-control input-custom input-full">
                                <input style="width:300px; margin-left:880px; margin-top:-39px;" type="file" name="img5"  class="form-control input-custom input-full">
                                

                                <label style="margin-left:40px;  margin-top:5px;" for = "price">Gallary Video:</label>
                                <br>
                                <input style="width:300px; margin-left:40px; " type="file" name="img6"  class="form-control input-custom input-full">
                            </div>
                             <input  style="width:300px; margin-left:500px; " type="submit"  name="add" value ="ADD"  class="btn btn-primary btn-lg">
                        </form>
                    </div>
                </div>
            </div>
        </section>
          <!-- Essential javascripts for application to work-->
   
  </body>
</html>
<?php 
include("footer.php");

?>